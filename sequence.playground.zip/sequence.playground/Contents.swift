import UIKit

let ana = "Ana Tertu"
let victor = "Victor Tertuliano"
let arthur = "Arthur"
let tere = "Teresinha"
let dido = "Virgil"

let familyArray = [ana, victor, arthur, tere, dido]
familyArray[1]
familyArray.first
print(familyArray)

let colorsSet = Set(["violet", "yellow", "blue", "white", "black", "violet", "yellow", "blue", "white", "black"])
colorsSet.first
print(colorsSet)

//tupla var = () or let = ()
var myNameTuple = (first1: """
Ana
Carolina
""", first: "Ana", last: "Santos", age: 40, childrens: true)
myNameTuple.0
myNameTuple.age
myNameTuple.childrens
print(myNameTuple)

//If you need a specific, fixed collection of related values where each item has a precise position or name, you should use a tuple:
let addressTuple = (house: 409, street: "Rua L", city: "New Yourk")
addressTuple.city
addressTuple.0

//If you need a collection of values that must be unique or you need to be able to check whether a specific item is in there extremely quickly, you should use a set:
let formsSet = Set(["cadeira", "mesa", "monitor"])

//If you need a collection of values that can contain duplicates, or the order of your items matters, you should use an array:
let pythonsArray = ["Eric", "Graham", "John", "Michael", "Terry", "Terry"]

let heightsDictionaries = [ 
    ana: 1.68,
    victor: 2,
    "Taylor Swift": 1.78,
    "Ed Sheeran": 1.73
]
heightsDictionaries[ana]

let favoriteIceCreamDictionary = [
    "Paul": "Chocolate",
    "Sophie": "Vanilla"
]

favoriteIceCreamDictionary["Charlotte", default: "Unknown"]
favoriteIceCreamDictionary["Ana"]
favoriteIceCreamDictionary["Paul", default: "Deseja cadastrar?"]
favoriteIceCreamDictionary["Paula", default: "Não consta nos registro"]

var teamsColorsDictionary = [String: String]()
print(teamsColorsDictionary)
teamsColorsDictionary["PaulKey"] = "RedValue"
print(teamsColorsDictionary)
teamsColorsDictionary["AnaKey"] = "VioletValue"
print(teamsColorsDictionary)

var resultArray = [Int]()
resultArray = [1, 2, 3]
resultArray[0]

var resulDictionary = [Int: String]()

var AlteraResultadoDictionary = [String: Int]()
AlteraResultadoDictionary["KeyString"] = 8
AlteraResultadoDictionary.count
AlteraResultadoDictionary.keys
AlteraResultadoDictionary["KeyString"]
AlteraResultadoDictionary["KeyString"] = 10
AlteraResultadoDictionary["KeyString"]


var wordsSet = Set<String>()
var numbersSet = Set<Int>()

var scoresDictionary = Dictionary<String, Int>()
var resultsArray = Array<Int>()

enum ResultEnum {
    case success
    case failure
}

let result1 = ResultEnum.failure
let result2 = ResultEnum.success



enum ActivityEnum {
    case prayCase
    case speakCase(inst: Bool)
    case runCase(destination: String)
    case talkCase(topic: String)
    case singCase(volume: Int)
}

let talkCase = ActivityEnum.talkCase(topic: "programmer")
let speakCase = ActivityEnum.speakCase(inst: true)


enum Planet: Int {
    case mercury = 3
    case venus
    case earth
    case mars
}

Planet(rawValue: 2)
Planet(rawValue: 4)

var weathersAB = "sunny"

switch weathersAB {
case "rain":
    print("Bring an umbrella")
case "snow":
    print("Wrap up warm")
case "sunny":
    print("Wear sunscreen")
    fallthrough
default:
    print("Enjoy your day!")
}


var favoriteColors = Dictionary<String, String>()
var measurements = [Double.self]
var measurement = [Int]()

var episodeNames = Array<Double>()
var badges = Set<Bool>()

var wines = Dictionary<String, String>()
var win = [String: String]()

var temperatures = [Double]()

var mountainHeights = [String: Int]()

var nameTupla = (first: "Ana", last: "Santos")
nameTupla.first
nameTupla.0

let ages: [Int] = ([26, 28, 39])

var repeatCount = [String: Int]()

let winners: [String] = (["David", "Jason", "Raquel"])

var result = ["Red", "Green"] + ["Blue"]

var resultA = 1
resultA *= 10

var resultB = 21
resultB -= 11

var resultC = 20
resultC /= 2

var favoriteColor = "Red"
if favoriteColor == "Red" {
    print("Success")
} else {
    print("Failure")
}

let isAvailable: Bool = true
if isAvailable {
    print("Success")
} else {
    print("Failure")
}

let test = false

if test == false {
    print("Hello, Swift!")
}

let loggedIn = true
let authorized = false

if loggedIn && authorized {
    print("Hello, Swift!")
}

let age1 = 18
let age2 = 21

if age1 > 18 || age1 < 18 {
    print("Hello, Swift!")
}

let score1 = 23
let score2 = 18

if score1 > 18 || score2 < 18 {
    print("Hello, Swift!")
}

let phone = "iPhone"
print(phone == "Android" ? "Failure" : "Success")

var averagePages: Double = 10.01
print(averagePages == 10 ? "Success" : "Failure")

let yourScore = 20
var highScore = 15
if yourScore >= highScore {
    print("You got the high score!")
}

var age = 18
switch age {
case 0...8:
    fallthrough
case 9..<18:
    print("You're still a minor")
default:
    print("You're an adult")
}

let height = 10
let width = 20
height < width

let tvShow = "Breaking " + "Bad"

for _ in 0...3 {
    print("Hip hip hurray!")
}

for beatle in ["John", "Paul", "Ringo"] {
    print("\(beatle) was in the Beatles")
}

var names = ["John", "Sophie", "Lottie"]
for name in names {
    print("Hello, \(name)!")
}

for number in [2, 3, 5] {
    print("\(number) is a prime number.")
}

let colors = ["Red", "Green", "Blue", "Orange", "Yellow"]
var colorCounter = 0
while colorCounter < 5 {
    print("\(colors[colorCounter]) is a popular color.")
    colorCounter += 1
}

var counter = 2
while counter < 64 {
    print("\(counter) is a power of 2.")
    counter *= 2
}

var page: Int = 0
while page <= 5 {
    page += 1
    print("I'm reading page \(page).")
}

var pianoLesson = 1
while pianoLesson <= 5 {
    print("This is lesson \(pianoLesson)")
    pianoLesson += 1
}

var cats: Int = 0
while cats < 10 {
    cats += 1
    print("I'm getting another cat.")
    if cats == 4 {
        print("Enough cats!")
        cats = 10
    }
}

var itemsSold: Int = 0
while itemsSold < 5000 {
    itemsSold += 100
    if itemsSold.isMultiple(of: 10000) {
        print("\(itemsSold) items sold - a big milestone!")
    }
}

var number: Int = 10
while number > 0 {
    number -= 2
    if number.isMultiple(of: 2) {
        print("\(number) is an even number.")
    }
}

var position = 5
while position > 0 {
    print("\(position)!")
    position -= 1
}

var averageScore = 2.5
while averageScore < 15.0 {
    averageScore += 2.5
    print("The average score is \(averageScore)")
}

var speed = 50
while speed <= 55 {
    print("Accelerating to \(speed)")
    speed += 1
}

for i in 1...10 {
    print("\(i)...")
}
print("Ready or not, here I come!")

var doubles = 0
var value = 1
repeat {
    doubles += 1
    value *= 2
    print("Value is \(value)")
} while doubles < 10

var countdown: Int = 5
repeat {
    print("\(countdown)...")
    countdown -= 1
} while countdown > 0
print("Lift off!")
            
var daysA = 365
while daysA < 320 {
     print("There are \(daysA) until my birthday!")
     daysA -= 1
}

var bagels = 5
repeat {
    print("Someone ate a bagel!")
    bagels -= 1
} while bagels > 0

var testRuns = 0
while testRuns < 10 {
    print("Testing!")
    testRuns += 1
}

var frogs = 4
repeat {
    for _ in 1...frogs {
        print("Ribbit!")
    }
} while false

var counterA = 0
while counterA < 5 {
    counterA += 1
    print("Counting: \(counterA)")
    print("Count: \(counter)")
}

var people = 2
while people < 10 {
    people += 2
    if people == 10 {
        print("We got 10 people.")
    }
}

for i in 1..<11 {
    if i == 10 {
        print("Found number 10!")
    }
}

for person in ["Taylor", "Justin", "Adele"] {
    print("Hello, \(person)!")
}

let firstScore = 13
let secondScore = 4

let total = firstScore + secondScore + 3
let difference = firstScore - secondScore - 4

let product = firstScore * secondScore
let divided = firstScore / secondScore

let remainder = firstScore % secondScore
