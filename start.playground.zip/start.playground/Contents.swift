import UIKit

struct Person {
    var type: String
    var action: String
}

// mutating func appendInterpolation(_ value: Int) {  --- indefinido , irá alterar toda interpolação de int para String - (_ value:
// mutating func appendInterpolation(format value: Int) {  --- somente a interpolação q chamar essa func irá ser alterada - (format value:
extension String.StringInterpolation{
    
    mutating func appendInterpolation(_ person: Person){
        appendLiteral("I'm a \(person.type) and I'm gonna \(person.action).")
    }
    
    mutating func appendInterpolation(_ person: Person, count: Int) {
        let action = String(repeating: "\(person.action)", count: count)
        appendLiteral("\n\(person.type.capitalized)s gonna \(action)")
    }
    
    mutating func appendInterpolation<T: Encodable>(debug value: T) throws {
        let encoder = JSONEncoder()
        encoder.outputFormatting = .prettyPrinted
        
        let result = try encoder.encode(value)
        let str = String(decoding: result, as: UTF8.self)
        appendLiteral(str)
    }
}

let player = Person(type: "player", action: "Play")
let playerLov = Person(type: "playerLov", action: "Love")
let heart = Person(type: "heartLov", action: "heart")

let loved = Person(type: "loved", action: "love")
print("Status check: \(loved)")
print(loved)

print("Let's sing: \(player, count: 5) \(playerLov, count: 5) \(heart, count: 5) \(loved, count: 5)")

